import { Aurelia } from 'aurelia-framework';
import * as environment from '../config/environment.json';
import { PLATFORM } from 'aurelia-pal';
import { Backend, TCustomAttribute } from 'aurelia-i18n';
// import {I18N, TCustomAttribute} from 'aurelia-i18n'; // <------------ 1
// import Backend from 'i18next-xhr-backend';
// import resBundle from 'i18next-resource-store-loader';

import 'bootstrap/dist/css/bootstrap.css';
import 'font-awesome/css/font-awesome.css';
import XHR from 'i18next-xhr-backend';
// import 'font-awesome/css/font-awesome.css';

export function configure(aurelia: Aurelia): void {
  aurelia.use
    .standardConfiguration()
    .plugin(PLATFORM.moduleName("aurelia-validation"))
    .plugin(PLATFORM.moduleName("aurelia-validatejs"))
    .plugin(PLATFORM.moduleName('aurelia-dialog'), (configuration) => {
      // use only attach-focus

      configuration.useDefaults();
      configuration.settings.lock = true;
      configuration.settings.centerHorizontalOnly = false;
      configuration.settings.startingZIndex = 5;
      configuration.settings.keyboard = true;
    })
   
    .plugin(PLATFORM.moduleName("aurelia-i18n"), (instance) => {
      let aliases = ['t', 'i18n'];
      // add aliases for 't' attribute
      // instance.i18next.use(XHR);
      TCustomAttribute.configureAliases(aliases);

      // register backend plugin
      instance.i18next.use(Backend.with(aurelia.loader));

      // adapt options to your needs (see http://i18next.com/docs/options/)
      // make sure to return the promise of the setup method, in order to guarantee proper loading
      //   return instance.setup({
      //     backend: {                                  // <-- configure backend settings
      //       loadPath: './src/locales/en/global.json', // <-- XHR settings for where to get the files from
      //     },
      //     ns: 'global', // <------------ 8
      //     defaultNS: 'global',
      //     fallbackNS: false,
      //     attributes: aliases, // <------------ 9
      //     lng: 'en', // <------------ 10
      //     fallbackLng: 'en',
      //     debug: false,
      //     locales: ['en'],
      //   });
      // });

      return instance.setup({
        backend: {                                    // <-- configure backend settings
          loadPath: PLATFORM.moduleName("./locales/en-EN/global.json"), // <-- XHR settings for where to get the files from
        },
        attributes: aliases,
        lng: 'en',
        debug: true,
      });
    });

  //   return instance.setup({
  //     fallbackLng: 'ru', // <------------ 6
  //     whitelist: ['en', 'ru'],
  //     preload: ['en', 'ru'], // <------------ 7
  //     ns: 'global', // <------------ 8
  //     defaultNS: 'global',
  //     fallbackNS: false,
  //     attributes: aliases, // <------------ 9
  //     lng: 'en', // <------------ 10
  //     debug: true, // <------------ 11
  //     backend: {                                  
  //       loadPath: './locales/{{lng}}/{{ns}}.json',  // <------------ 12
  //     }
  //   });
  // });


  // .feature(PLATFORM.moduleName('resources/index'));

  aurelia.use.developmentLogging(environment.debug ? 'debug' : 'warn');

  if (environment.testing) {
    aurelia.use.plugin(PLATFORM.moduleName('aurelia-testing'));
  }

  aurelia.start().then(() => aurelia.setRoot(PLATFORM.moduleName('app')));
}
