import { bindable } from "aurelia-framework";
import { inject } from 'aurelia-dependency-injection';
import APIService from './api-service';

import { Router } from 'aurelia-router';
import { I18N } from 'aurelia-i18n';
import { DialogService } from 'aurelia-dialog';
import { DialogWindow } from './dialog-window';

@inject(APIService, Router, I18N, DialogService)
export class Login {
  public message: string = "Welcome";
  dialogService: DialogService;
  public statusMsg: string = "";

  
  router: Router;
  constructor(private _service: APIService, private route: Router, private i18n: I18N, dialogService: DialogService) {
    
  }

  openModal() {
    
  }


  moveToRegister() {
    // this.router.na("registration?id=4");
    // this.router.navigate(['registration'], { queryParams: { page: 4 } });
  }

  edit() {
  }
}