import {bindable} from "aurelia-framework";
import { inject } from 'aurelia-dependency-injection';
import { Router } from 'aurelia-router';


@inject(Router)
export class SuccessMessage {
  @bindable
  public successMessage: string = "Applicant information has been registered successfully.."

  router:Router;
  constructor(private route:Router) {    
    this.router = route;
  }
    
  moveToRegister() {
    this.router.navigateToRoute("welcome");
  }

}