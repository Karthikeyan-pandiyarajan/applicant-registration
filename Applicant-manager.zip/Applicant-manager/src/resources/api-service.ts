//import { HttpClient as client } from 'aurelia-http-client';
import { IApplicant } from './session';
import { HttpClient, json } from 'aurelia-fetch-client';

// import { inject } from 'aurelia-framework';
// @inject(HttpClient)
export default class ApiService {

  httpClient: HttpClient = new HttpClient();

  countryApiUrl = 'https://restcountries.eu/rest/v2'
  // constructor(private http: HttpClient) {
  //   // this.http = http;
  //   // http.configure(config => {
  //   //   config
  //   //     .withDefaults({
  //   //       headers: {
  //   //         'Content-Type': 'application/json',
  //   //         'Accept': '*/*'
  //   //       }
  //   //     })
  //   // });

  //   this.http = http;
  // }

  url: string = 'https://localhost:5001';
  GetCountryOrigins(){
    var req: RequestInit = {
      method: "GET",
    }
    return this.httpClient.fetch(this.countryApiUrl, req);
  }
  
  GetApplicants() {
    var req: RequestInit = {
      method: "GET",
    }
    return this.httpClient.fetch('https://localhost:5001/Applicant');
  }

  GetApplicant(id: number) {
    return this.httpClient.fetch(`${this.url}/Applicant/${id}`);
  }

  PostApplicant(applicant: any) {

    var ss = JSON.stringify(applicant);
    const headers = new Headers();
    // headers.append("Accept", "*/*");
    headers.append("Content-Type", "application/json");
    
    var req: RequestInit = {
      method: "POST",
      body: ss,
      headers: headers

    }
     return this.httpClient.fetch('https://localhost:5001/Applicant', req);
  }
  

  PutApplicant(applicant: IApplicant, id: number) {
    const headers = new Headers();
    // headers.append("Accept", "*/*");
    headers.append("Content-Type", "application/json");
   
    var req: RequestInit = {
      method: "PUT",
      body: json(applicant),
      headers: headers

    }
    return this.httpClient.fetch(`${this.url}/Applicant/${id}`, req);
  }

  DeleteApplicant(id: number) {
    const headers = new Headers();
    // headers.append("Accept", "*/*");
    headers.append("Content-Type", "application/json");
    var req: RequestInit = {
      method: "DELETE",
      headers: headers
    }

    var deleteUrl = this.url + '/Applicant/'+ id.toString() 
    return this.httpClient.fetch(deleteUrl, req);
  }



}
