import { bindable } from "aurelia-framework";
import { inject } from 'aurelia-dependency-injection';
import APIService from './api-service';
import { IApplicant } from 'resources/session';
import { Router } from 'aurelia-router';
import { I18N } from 'aurelia-i18n';
import { DialogService } from 'aurelia-dialog';
import { DialogWindow } from './dialog-window';

@inject(APIService, Router, I18N, DialogService)
export class Welcome {
  public message: string = "Welcome";
  dialogService: DialogService;
  public statusMsg: string = "";

  public applicantList: IApplicant[] = [];
  router: Router;
  constructor(private _service: APIService, private route: Router, private i18n: I18N, dialogService: DialogService) {
    this.dialogService = dialogService;
    this.i18n = i18n;
    console.log(this.i18n);
    this.router = route;
    this._service.GetApplicants().then((res) => {
      res.json().then((data) => {
          data.data.forEach(applicant => {
            var applicantObj: IApplicant = {
              name: applicant.name,
              familyName: applicant.familyName,
              address: applicant.id,
              age: applicant.age,
              countryOfOrigin: applicant.countryOfOrigin,
              emailAddress: applicant.emailAddress,
              id: applicant.id,
              hired: applicant.hired
            }
            this.applicantList.push(applicantObj);
          });
          this.SetMessage();
          console.log(this.applicantList);
        });
        
    });
    console.log("SetMessage1");
    this.SetMessage();
  }

  openModal(app: IApplicant) {
    
    this.dialogService.open({ viewModel: DialogWindow, model: 'Do you want to delete?', lock: false }).whenClosed(response => {
      if (!response.wasCancelled) {
        this.Delete(app)
      } else {
      }
    });
  }


  moveToRegister() {
    // this.router.na("registration?id=4");
    // this.router.navigate(['registration'], { queryParams: { page: 4 } });
  }

  edit(app: IApplicant) {
    console.log(app);
  }

  Delete(app: IApplicant) {
    this._service.DeleteApplicant(app.id).then((res: Response) => {
      console.log(res.status)
      if(res.status === 204){
        let index = this.applicantList.findIndex(d => d.id === app.id); //find index in your array
        this.applicantList.splice(index, 1);//remove element from array
        this.SetMessage();
      }      
    });
  }

  SetMessage() {
    console.log("SetMessage");
    this.statusMsg = this.applicantList.length === 0 ? "No applicants found..." : "";
    // if (this.applicantList.length === 0) {
    //   this.statusMsg = "No applicants found...";
    // }
    // else{
    //   this.statusMsg = "Welcome";
    // }
  };

}