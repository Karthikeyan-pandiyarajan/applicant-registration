import {bindable} from "aurelia-framework";
import {ValidationController, ValidationRules} from "aurelia-validation";
import {inject, NewInstance} from "aurelia-dependency-injection";
import { Router } from 'aurelia-router';

@inject(NewInstance.of(ValidationController), Router)
export class PersonDetail {
  // router: Router;
  @bindable
  public person;
  router:Router;
  constructor(private validationController: ValidationController, private route:Router) 
  {
    this.router = route;
  }

  public bind() {
    // ValidationRules
    //   .ensure("firstName").required()
    //   .ensure("lastName").required().withMessage("My custom error message")
    //   .on(this.person);
  }

  submit() {
    this.router.navigateToRoute("welcome");
  }
}
