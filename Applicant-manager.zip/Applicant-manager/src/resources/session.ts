export class Session {
  record = {
    Name: '',
    FamilyName: '',
    Address: '',
    CountryOfOrigin: '',
    EmailAddress: '',
    Age: '',
    Hired: '',
    DOB: ''
  }
  
  reset() {
    this.record.Name = '';
    this.record.FamilyName = '';
    this.record.Address = '';
    this.record.CountryOfOrigin = '';
    this.record.EmailAddress = '';
    this.record.Age = '';
    this.record.Hired = '';
    this.record.DOB = ''
  }
}

export interface IApplicant {
  address: string,
  age: number,
  countryOfOrigin: string,
  emailAddress: string,
  familyName: string,
  hired?: boolean | string,
  id?: number,
  name: string,
  dob?: string
}

export interface ICountryOrigin{
  name: string
}