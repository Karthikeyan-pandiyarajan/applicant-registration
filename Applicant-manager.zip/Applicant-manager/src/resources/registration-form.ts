import { inject } from 'aurelia-dependency-injection';
import { ValidationControllerFactory, ValidationController, ValidationRules } from 'aurelia-validation';
import { IApplicant, ICountryOrigin, Session } from './session';
import { BootstrapFormRenderer } from '../bootstrap-form-renderer';
import APIService from './api-service';
import { bindable } from "aurelia-framework";
import { Router } from 'aurelia-router';
import { DialogService } from 'aurelia-dialog';
import { DialogWindow } from './dialog-window';
import { ErrorDialog } from './error-dialog'
import * as moment from 'moment'


@inject(ValidationControllerFactory, Session, APIService, Router, DialogService)
export class RegistrationForm {
  controller = null;
  session = null;
  service = null;
  router: Router;
  dialogService: DialogService;

  @bindable
  public orginList: ICountryOrigin[] = [];
  public actionText: string = "Submit";
  @bindable
  public isFormInValid: boolean = true;
  public enableReset: boolean = false;
  applicantId: number = 0;
  
  constructor(controllerFactory, session, service, route: Router, dialogService: DialogService) {
    this.dialogService = dialogService;
    this.router = route;
    this.controller = controllerFactory.createForCurrentScope();
    this.controller.addRenderer(new BootstrapFormRenderer());
    this.session = session;
    this.service = service;

    ValidationRules
      .ensure("Name").required()
      .ensure("FamilyName").required()
      .ensure("Address").required()
      .ensure("CountryOfOrigin").required()
      .ensure("EmailAddress").required().email()
      .ensure("DOB").required()
      .on(this.session.record);

    this.service.GetCountryOrigins().then((res) => {
      res.json()
        .then((data) => {
          var items = data.map(x => x.name)
          items.forEach(element => {
            var item: ICountryOrigin = {
              name: element
            }
            this.orginList.push(item)
          });
        });
    });

    // this.validDate();
  }

  activate(parms) {
    console.log(parms.id);
    if (parms.id !== undefined) {
      this.actionText = "Update";
      this.applicantId = parms.id;
      this.service.GetApplicant(parms.id).then((res) => {
        res.json()
          .then((data) => {
            console.log(data.data)
            var result = data.data;
            this.session.record.Name = result.name,
              this.session.record.FamilyName = result.familyName,
              this.session.record.Address = result.address,
              this.session.record.CountryOfOrigin = result.countryOfOrigin,
              this.session.record.EmailAddress = result.emailAddress,
              this.session.record.Hired = result.hired
            this.session.record.DOB = result.DOB
          });
      });
    }
  }

  getIsFormInValid() {
    const emptyValue = '';
    if (this.session.record.Name === emptyValue
      || this.session.record.FamilyName === emptyValue
      || this.session.record.Address === emptyValue
      || this.session.record.CountryOfOrigin === emptyValue
      || this.session.record.EmailAddress === emptyValue) {
      this.isFormInValid = true;
    }
    else {
      this.isFormInValid = false;
    }

    if (this.session.record.Name !== emptyValue
      || this.session.record.FamilyName !== emptyValue
      || this.session.record.Address !== emptyValue
      || this.session.record.CountryOfOrigin !== emptyValue
      || this.session.record.EmailAddress !== emptyValue) {
      this.enableReset = true;
    }
    else {
      this.enableReset = false;
    }

  }

  getInputDateFormat(date) {
    return date.toISOString().split('T')[0];
  }


  openModal() {
    this.dialogService.open({ viewModel: DialogWindow, model: 'Do you want to remove the changes?', lock: false }).whenClosed(response => {
      if (!response.wasCancelled) {
        this.reset();
      } else {
      }
    });
  }

  openErrorModal(msg: string) {
    this.dialogService.open({ viewModel: ErrorDialog, model: msg, lock: false }).whenClosed(response => {
      if (!response.wasCancelled) {
      } else {
      }
    });
  }

  moveToSuccessMessage() {
    this.reset();
    this.router.navigateToRoute("successmessage");
  }

  moveToHome() {
    this.reset();
    this.router.navigateToRoute("welcome");
  }

  convertToBoolean(input: string): boolean | null {
    try {
      return JSON.parse(input);
    }
    catch (e) {
      return null;
    }
  }

  validateAge(age: number, min: number, max: number): boolean {

    return age >= min && age <= max;
  }

  getAge(dateOfBirth: any): number {

    return moment().diff(dateOfBirth, 'years');
  }

  postApplicantInfo(input: any) {
    this.service.PostApplicant(input)
      .then((res: Response) => {
        if (res.ok) {
          res.json()
            .then((data) => {
              this.moveToSuccessMessage();
            },
              (error) => {
                this.openErrorModal('An unexpected error occured ' + error)
              });
        }
        else {
          res.json()
            .then((data) => {
              console.log(data);
              var errorItems: string[] = [];
              data.data.forEach(applicant => {

                errorItems.push(applicant.errorMessage)
              });
              var msg = errorItems.join(",");
              this.openErrorModal(msg)
            },
              (error) => {
                this.openErrorModal('An unexpected error occured ' + error)
              });
        }
      });
  }

  putApplicantInfo(input: any, id: number) {
    this.service.PutApplicant(input, id)
      .then((res: Response) => {
        if (res.ok) {
          res.json()
            .then((data) => {
              this.moveToHome();
            },
              (error) => {
                this.openErrorModal('An unexpected error occured ' + error)
              });
        }
        else {
          res.json()
            .then((data) => {
              console.log(data);
              var errorItems: string[] = [];
              data.data.forEach(applicant => {

                errorItems.push(applicant.errorMessage)
              });
              var msg = errorItems.join(",");
              this.openErrorModal(msg)
            },
              (error) => {
                this.openErrorModal('An unexpected error occured ' + error)
              });
        }
      });
  }

  getApplicantInfo(): IApplicant {

    var appObj: IApplicant = {
      name: this.session.record.Name,
      familyName: this.session.record.FamilyName,
      address: this.session.record.Address,
      countryOfOrigin: this.session.record.CountryOfOrigin,
      emailAddress: this.session.record.EmailAddress,
      age: this.getAge(this.session.record.DOB),
      hired: this.session.record.Hired !== undefined ? this.convertToBoolean(this.session.record.Hired) : '',
      dob: this.session.record.DOB
    }
    return appObj;
  }

  submit() {
    const currentAge = this.getAge(this.session.record.DOB);
    if (!this.validateAge(currentAge, 20, 50)) {
      this.openErrorModal("Age must be between 20 to 50")
      return;
    }
    let app = this.getApplicantInfo();

    var input = {
      data: app
    };

    this.controller.validate().then(result => {
      if (result.valid) {

        if (this.applicantId > 0) {
          this.putApplicantInfo(app, this.applicantId)
        }
        else {
          this.postApplicantInfo(input);
        }

      }
    });

  }

  reset() {
    this.controller.reset();
    this.session.reset();
    document.getElementById("validationTest");
  }
}