
import { RouterConfiguration, Router } from 'aurelia-router';
import { PLATFORM } from 'aurelia-pal';
import {I18N} from 'aurelia-i18n';
import { inject } from 'aurelia-dependency-injection';

@inject(I18N)
export class App {
  router: Router;

  public message = 'Hello World!';
  // heading = "Todos";
  // todos: Todo[] = [];
  // todoDescription = '';

  // addTodo() {
  //   if (this.todoDescription) {
  //     this.todos.push({
  //       description: this.todoDescription,
  //       done: false
  //     });
  //     this.todoDescription = '';
  //   }
  // }

  // removeTodo(todo) {
  //   let index = this.todos.indexOf(todo);
  //   if (index !== -1) {
  //     this.todos.splice(index, 1);
  //   }
  // }
  // i18n:I18N;
  configureRouter(config: RouterConfiguration, router: Router): void {
    // this.i18n = i18n;
    // // console.log(this.i18n.getLocale());
    // this.i18n
    // .setLocale('en')
    // .then( () => {
    //   console.log('Locale is ready!');
    //   // locale is loaded
    // });
    // console.log(this.i18n.tr('welcome'));
    // this.i18n.updateTranslations()
    // .then( () => {
    //    console.log('Locale is ready!');
    // });
    config.title = 'Aurelia';
    config.options.pushState = true;
    config.options.root = '/';
    config.map([
      { route: ['', 'home'], name: 'welcome', moduleId: PLATFORM.moduleName('resources/welcome-page'), nav: true, title: 'Welcome' },
      { route: 'welcome', name: 'person', moduleId: PLATFORM.moduleName('resources/person-detail'), nav: true },
      { route: 'registration/:id?', name: 'registration', moduleId: PLATFORM.moduleName('resources/registration-form')},
      { route: 'successmessage', name: 'successmessage', moduleId: PLATFORM.moduleName('resources/success-message'), nav: true },
      {
        route:'login',name:'login',moduleId:PLATFORM.moduleName('resources/login')
      }

      // { route: 'users/:id/detail', name: 'userDetail', moduleId: 'users/detail' },
      // { route: 'files/*path',      name: 'files',      moduleId: 'files/index', nav: 0,    title: 'Files', href:'#files' }
    ]);
    this.router = router;
  }
}
