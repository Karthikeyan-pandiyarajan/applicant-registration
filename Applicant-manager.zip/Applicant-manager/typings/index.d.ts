/// <reference path="globals/validatejs/index.d.ts" />
/// <reference path="modules/aurelia-dialog/index.d.ts" />
